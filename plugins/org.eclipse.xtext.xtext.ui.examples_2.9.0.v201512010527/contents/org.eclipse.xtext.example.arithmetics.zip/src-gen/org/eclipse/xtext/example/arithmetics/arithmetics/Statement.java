/**
 */
package org.eclipse.xtext.example.arithmetics.arithmetics;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Statement</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.xtext.example.arithmetics.arithmetics.ArithmeticsPackage#getStatement()
 * @model
 * @generated
 */
public interface Statement extends EObject
{
} // Statement
