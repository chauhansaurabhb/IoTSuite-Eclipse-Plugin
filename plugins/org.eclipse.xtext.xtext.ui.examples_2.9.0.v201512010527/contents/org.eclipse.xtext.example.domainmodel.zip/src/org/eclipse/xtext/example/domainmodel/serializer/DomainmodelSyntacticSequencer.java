package org.eclipse.xtext.example.domainmodel.serializer;

public class DomainmodelSyntacticSequencer extends AbstractDomainmodelSyntacticSequencer {
}
